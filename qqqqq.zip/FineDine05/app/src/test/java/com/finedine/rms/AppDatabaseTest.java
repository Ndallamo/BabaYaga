package com.finedine.rms;

import junit.framework.TestCase;

public class AppDatabaseTest extends TestCase {

    public void testUserDao() {
    }

    public void testReservationDao() {
    }

    public void testOrderDao() {
    }

    public void testInventoryDao() {
    }

    public void testMenuItemDao() {
    }

    public void testOrderItemDao() {
    }

    public void testGetDatabase() {
    }

    public void testGetOrderRef() {
    }

    public void testTestUserDao() {
    }

    public void testTestReservationDao() {
    }

    public void testTestOrderDao() {
    }

    public void testTestInventoryDao() {
    }

    public void testTestMenuItemDao() {
    }

    public void testTestOrderItemDao() {
    }

    public void testTestGetDatabase() {
    }

    public void testTestGetOrderRef() {
    }
}