package com.finedine.rms;

import junit.framework.TestCase;

public class OrderItemTest extends TestCase {

    public void testGetItemId() {
    }

    public void testSetItemId() {
    }

    public void testTestGetName() {
    }

    public void testTestSetName() {
    }

    public void testGetQuantity() {
    }

    public void testSetQuantity() {
    }

    public void testGetOrderId() {
    }

    public void testSetOrderId() {
    }
}