package com.finedine.rms;

public class OrderItemImpl extends OrderItem {
    public OrderItemImpl() {
    }
}
