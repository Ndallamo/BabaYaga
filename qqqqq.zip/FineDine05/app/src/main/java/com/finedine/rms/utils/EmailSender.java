package com.finedine.rms.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class EmailSender {
    private static final String TAG = "EmailSender";
    private static final String EMAIL_PREFS = "EmailPreferences";
    private static final String KEY_GMAIL_EMAIL = "gmail_email";
    private static final String KEY_GMAIL_PASSWORD = "gmail_password";
    private static final String KEY_OUTLOOK_EMAIL = "outlook_email";
    private static final String KEY_OUTLOOK_PASSWORD = "outlook_password";
    private static final String KEY_PREFERRED_SERVICE = "preferred_email_service";

    /**
     * Save email credentials to SharedPreferences
     *
     * @param context         The application context
     * @param gmailEmail      Gmail email address
     * @param gmailPassword   Gmail app password
     * @param outlookEmail    Outlook email address
     * @param outlookPassword Outlook app password
     */
    public static void setEmailCredentials(Context context, String gmailEmail, String gmailPassword,
                                           String outlookEmail, String outlookPassword) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();

            editor.putString(KEY_GMAIL_EMAIL, gmailEmail);
            editor.putString(KEY_GMAIL_PASSWORD, gmailPassword);
            editor.putString(KEY_OUTLOOK_EMAIL, outlookEmail);
            editor.putString(KEY_OUTLOOK_PASSWORD, outlookPassword);

            // Default to Gmail if available
            if (!gmailEmail.isEmpty() && !gmailPassword.isEmpty()) {
                editor.putString(KEY_PREFERRED_SERVICE, "gmail");
            } else if (!outlookEmail.isEmpty() && !outlookPassword.isEmpty()) {
                editor.putString(KEY_PREFERRED_SERVICE, "outlook");
            }

            editor.apply();
            Log.d(TAG, "Email credentials saved successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error saving email credentials", e);
        }
    }

    /**
     * Get Gmail email address
     */
    public static String getGmailEmail(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_GMAIL_EMAIL, "");
    }

    /**
     * Get Gmail password
     */
    public static String getGmailPassword(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_GMAIL_PASSWORD, "");
    }

    /**
     * Get Outlook email address
     */
    public static String getOutlookEmail(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_OUTLOOK_EMAIL, "");
    }

    /**
     * Get Outlook password
     */
    public static String getOutlookPassword(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_OUTLOOK_PASSWORD, "");
    }

    /**
     * Get preferred email service (gmail or outlook)
     */
    public static String getPreferredEmailService(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_PREFERRED_SERVICE, "gmail");
    }

    /**
     * Set preferred email service
     */
    public static void setPreferredEmailService(Context context, String service) {
        if (!"gmail".equals(service) && !"outlook".equals(service)) {
            Log.e(TAG, "Invalid email service: " + service);
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(EMAIL_PREFS, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_PREFERRED_SERVICE, service).apply();
    }

    /**
     * Check if email credentials are set
     */
    public static boolean areEmailCredentialsSet(Context context) {
        String preferredService = getPreferredEmailService(context);

        if ("gmail".equals(preferredService)) {
            return !getGmailEmail(context).isEmpty() && !getGmailPassword(context).isEmpty();
        } else {
            return !getOutlookEmail(context).isEmpty() && !getOutlookPassword(context).isEmpty();
        }
    }

    /**
     * Send an email (implementation to be added)
     */
    public static void sendEmail(Context context, String recipient, String subject, String body) {
        // This would be implemented with JavaMail or similar library
        Log.d(TAG, "Email sending functionality to be implemented");
        // For now, just log the attempt
        Log.d(TAG, "Would send email to: " + recipient + ", Subject: " + subject);
    }
}