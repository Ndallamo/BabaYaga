package com.finedine.rms.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

public class SharedPrefsManager {
    private static final String TAG = "SharedPrefsManager";
    private static final String PREFS_NAME = "FineDinePrefs";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_ROLE = "user_role";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_FCM_TOKEN = "fcm_token";
    private static final String KEY_LAST_SYNC = "last_sync";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";

    private final SharedPreferences prefs;

    public SharedPrefsManager(Context context) {
        if (context == null) {
            Log.e(TAG, "Context is null in SharedPrefsManager constructor");
            throw new IllegalArgumentException("Context cannot be null");
        }

        try {
            prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            // Test immediately if we can access the prefs
            prefs.getBoolean(KEY_IS_LOGGED_IN, false);
            Log.d(TAG, "SharedPreferences initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "Failed to initialize SharedPreferences", e);
            throw e; // Re-throw to let caller know initialization failed
        }
    }

    public void saveUserSession(int userId, String role, String name) {
        Log.d(TAG, "Saving user session - userId: " + userId + ", role: " + role + ", name: " + name);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putInt(KEY_USER_ID, userId);
                editor.putString(KEY_USER_NAME, name);

                // Always set the role explicitly to ensure it's saved correctly
                if (role != null && !role.isEmpty()) {
                    Log.d(TAG, "Explicitly setting role: " + role);
                    editor.putString(KEY_USER_ROLE, role);
                } else {
                    Log.w(TAG, "Role is null or empty, using default 'customer'");
                    editor.putString(KEY_USER_ROLE, "customer");
                }

                // Always set user as logged in when saving a session
                editor.putBoolean(KEY_IS_LOGGED_IN, true);

                // Use commit() instead of apply() to ensure immediate write
                boolean success = editor.commit();

                if (success) {
                    Log.d(TAG, "User session saved successfully with commit()");
                } else {
                    Log.w(TAG, "Commit returned false, session may not be saved properly");
                }
            } else {
                Log.w(TAG, "Not saving session due to old Android version");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error saving user session", e);
        }

        // Double check that role was saved correctly
        String savedRole = getUserRole();
        boolean isLoggedIn = isUserLoggedIn();
        Log.d(TAG, "User session saved. Role: " + savedRole + ", IsLoggedIn: " + isLoggedIn);

        // If role wasn't saved correctly, try a direct approach
        if (role != null && !role.equals(savedRole)) {
            Log.w(TAG, "Role mismatch, forcing direct role setting");
            setUserRole(role);
        }

        // If login status wasn't saved correctly, try a direct approach
        if (!isLoggedIn) {
            Log.w(TAG, "Login status mismatch, forcing direct login setting");
            setUserLoggedIn(true);
        }
    }

    public int getUserId() {
        return prefs.getInt(KEY_USER_ID, -1);
    }

    public String getUserRole() {
        String role = prefs.getString(KEY_USER_ROLE, "customer");
        Log.d(TAG, "Getting user role from SharedPreferences: " + role);
        return role;
    }

    public String getUserName() {
        return prefs.getString(KEY_USER_NAME, "");
    }

    public void clearUserSession() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefs.edit()
                    .remove(KEY_USER_ID)
                    .remove(KEY_USER_ROLE)
                    .remove(KEY_USER_NAME)
                    .remove(KEY_IS_LOGGED_IN)
                    .apply();
        }
    }

    public void saveFcmToken(String token) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefs.edit().putString(KEY_FCM_TOKEN, token).apply();
        }
    }

    public String getFcmToken() {
        return prefs.getString(KEY_FCM_TOKEN, null);
    }

    public void setLastSyncTime(long timestamp) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefs.edit().putLong(KEY_LAST_SYNC, timestamp).apply();
        }
    }

    public long getLastSyncTime() {
        return prefs.getLong(KEY_LAST_SYNC, 0);
    }

    // Helper method to directly set the role (for debugging)
    public void setUserRole(String role) {
        Log.d(TAG, "DIRECTLY setting user role to: " + role);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefs.edit()
                    .putString(KEY_USER_ROLE, role)
                    .apply();
        }
    }

    public void setUserLoggedIn(boolean isLoggedIn) {
        Log.d(TAG, "Setting user logged in status to: " + isLoggedIn);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.GINGERBREAD) {
            prefs.edit()
                    .putBoolean(KEY_IS_LOGGED_IN, isLoggedIn)
                    .apply();
        }

        // Verify the value was saved correctly
        boolean storedValue = isUserLoggedIn();
        if (storedValue != isLoggedIn) {
            Log.w(TAG, "Login status mismatch! Expected: " + isLoggedIn + ", Got: " + storedValue);
            // Try using commit instead of apply as a fallback
            prefs.edit().putBoolean(KEY_IS_LOGGED_IN, isLoggedIn).commit();
        }
    }

    public boolean isUserLoggedIn() {
        boolean loggedIn = false;
        try {
            loggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false);
            Log.d(TAG, "Checking if user is logged in: " + loggedIn);
        } catch (Exception e) {
            Log.e(TAG, "Error checking login status, assuming not logged in", e);
        }
        return loggedIn;
    }
}